#include <algorithm>
#include <time.h>
#include <random>
#include<iostream>
#include "game.h"
#include <allegro5/allegro.h>
using namespace  std;
const int maxn = 1000000000;

extern int monsters_id;
Scene fight_scene_create(int id);

class Role{
    public:
        int level, def, atk, hp, luck;
        // luck up to 600 
        Role(int _level = 1, int _def = 10, int _luck = 50, int _atk = 20, int _hp = 100): level(_level), def(_def), luck(_luck), atk(_atk), hp(_hp){};
        
        pair<int,bool> attack(Role &obj){
            bool crit = (rand()%1000 < luck );
			int det = max( (crit?2:1) * atk + rand()%20 - obj.def , 1 );
            obj.hp -= det;  
			return make_pair(det,crit); 
        }

        bool died(){
            return hp<=0;
        }
};

class Player: public Role{
    public:
        int exp, skill_cnt, org_hp;
        //ALLEGRO_BITMAP* op = al_load_bitmap("kirito.jpg");
        // exp up to 100
        // level up to 100
        Player(int _exp = 0, int _skill = 0):exp(_exp), skill_cnt(_skill), org_hp(hp){luck = 100;};
        void init(){
            hp = org_hp;
		}
        bool level_up(int id){
            exp += ++id*75;
            cout<<exp<<endl;
            if(level == 100|| exp<100) return 0;
            int det = min(exp / 100, 100 - level);
            exp %= 100;
            luck += 10*det;
            skill_cnt += 3 * det; 
            level = min(100, level + det);
            org_hp += 10 * det;
            atk += 10 * det;
            def += 5* det;
        	return 1;
		}
};

class Monster:public Role{
    public:
    ALLEGRO_BITMAP *ms;
    Monster(int id = 0){
    	level = id;
        if(id){
            def += 2*id;
            atk += 2*id;
            hp += 2*id;
        }
//        if(id==0) ms = al_load_bitmap("ms0.png");
//    	else if(id==1) ms = al_load_bitmap("ms1.png");
//    	else if(id==2) ms = al_load_bitmap("ms2.png");
//		else if(id==3) ms = al_load_bitmap("ms3.png");
//		else if(id==4) ms = al_load_bitmap("ms4.png");
	}
};

bool start_fight(int id);