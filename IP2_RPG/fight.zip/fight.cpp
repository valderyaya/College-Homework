#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include<random>
#include<time.h>
#include<algorithm>
#include "fight.h"
#include "game.h"
#include <tuple>


ALLEGRO_FONT* font;
Player pl;
Monster mons;
static int monsters_id;
static char xp[50],yp[50],zp[10];
static int dmg,turn;
static bool crt,upd;
static ALLEGRO_TIMER* turn_timer;

static void init(){
	puts("fight init");
	pl.init();
	turn = upd = 0;
	mons= Monster(monsters_id);
	font = al_create_builtin_font();
//	al_set_timer_count(turn_timer,0);
//	al_set_timer_speed(turn_timer,1);
//	al_start_timer(turn_timer);
}

static void draw(){
	puts("fight draw");
	al_clear_to_color(al_map_rgb(0, 0, 0));
	sprintf(xp,"HP: %d",std::max(0,pl.hp));
	sprintf(yp,"HP: %d",std::max(0,mons.hp));
	sprintf(zp,"- %d",dmg);
	al_draw_text(font,al_map_rgb(255,255,255), 200, 300, 0, xp);
	al_draw_text(font,al_map_rgb(255,255,255), 600, 300, 0, yp);
	//al_draw_bitmap(pl.op,200,400,0);
	//al_draw_bitmap(
	if(mons.died()){
		al_draw_text(font,al_map_rgb(255,255,255), 350, 400, 0, "You Win!");
	}else if(pl.died()){
		al_draw_text(font,al_map_rgb(255,255,255), 350, 400, 0, "You Died!");
	}
	if(upd){
		al_draw_text(font,al_map_rgb(255,255,255), 350, 350, 0, "Level up!");
		char tmp[5];
		sprintf(tmp,"%d",pl.level);
		al_draw_text(font,al_map_rgb(255,255,255), 350, 370, 0, tmp);
	}
	if(crt) al_draw_text(font,al_map_rgb(255,255,255), 400, 270, 0, "Crit!");
	if(!turn) {
		al_flip_display();
		return;
	}
	if(turn & 1){
		al_draw_text(font,al_map_rgb(255,255,255), 600, 350, 0, zp);
	}else if(!(turn & 1)){
		al_draw_text(font,al_map_rgb(255,255,255), 200, 350, 0, zp);
	}
	al_flip_display();
}

static void update(){
	puts("fight update");
	if(mons.died()||pl.died()){
		puts("end");
		// change scene
		return;
	}
	if((++turn) & 1){
		std::tie(dmg,crt) = pl.attack(mons);
		if(mons.died()) upd = pl.level_up(mons.level);
	}else
		std::tie(dmg,crt) = mons.attack(pl);
}



Scene fight_scene_create(int id) {
	puts("fight scene create");
	Scene scene;
	memset(&scene, 0, sizeof(Scene));
	scene.name = "Fight";
	monsters_id=id;
	scene.initialize = &init;
	scene.draw = &draw;
	scene.update = &update;
	return scene;
}